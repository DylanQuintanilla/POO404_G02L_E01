package udb.edu.guiabeans;

public class ClienteBeans {
    private String nomb_cli;

    public String getApe_cli() {
        return ape_cli;
    }

    public void setApe_cli(String ape_cli) {
        this.ape_cli = ape_cli;
    }

    public String getDir_cli() {
        return dir_cli;
    }

    public void setDir_cli(String dir_cli) {
        this.dir_cli = dir_cli;
    }

    public String getNomb_cli() {
        return nomb_cli;
    }

    public void setNomb_cli(String nomb_cli) {
        this.nomb_cli = nomb_cli;
    }

    private String ape_cli;
    private String dir_cli;
}
